package com.example.ettamin

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
